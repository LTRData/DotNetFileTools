﻿Imports LTRLib.Extensions
Imports LTRLib.MathExpression
Imports System.Globalization
Imports System.Linq.Expressions
Imports System.Reflection

Module Module1

    Function Main(args As String()) As Integer
        Try
            Return CatchingMain(args)

        Catch ex As Exception
            Console.Error.WriteLine(ex.ToString())
            For Each asm In AppDomain.CurrentDomain.GetAssemblies()
                Console.WriteLine(asm.FullName & ": " & asm.Location)
            Next
            Return -1

        End Try
    End Function

End Module
